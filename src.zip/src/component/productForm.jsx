import { useEffect, useState } from "react";

export default function ProductForm({ onSubmit, selectedProduct }) {
  const [form, setForm] = useState({
    title: "",
    price: "",
  });

  useEffect(() => {
    if (selectedProduct) {
      setForm({
        title: selectedProduct.title,
        price: selectedProduct.price,
      });
    }
  }, [selectedProduct]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(selectedProduct?.id, form);
    setForm({ title: "", price: "" });
  };

  return (
    <div className="card shadow-sm mb-4">
      <div className="card-body">
        <h5 className="card-title mb-3">
          {selectedProduct ? "Edit Product" : "Add Product"}
        </h5>

        <form onSubmit={handleSubmit}>
          <input
            type="text"
            name="title"
            placeholder="Product Title"
            value={form.title}
            onChange={handleChange}
            className="form-control mb-3"
            required
          />
          <input
            type="number"
            name="price"
            placeholder="Price"
            value={form.price}
            onChange={handleChange}
            className="form-control mb-3"
            required
          />
          <button className="btn btn-primary w-100">
            {selectedProduct ? "Update" : "Add"} Product
          </button>
        </form>
      </div>
    </div>
  );
}
